# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
BulkImport_And_Configuration.ps1
- Example scripts to illustrate how to bulk import multiple systems and configuration.
#>

# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"

# Define the configuration pattern (name) for flex compute node and rack server
$configPattern = @{
    flex = "Flex_Pattern"
    rack = "Rack_Pattern"
    }

# Define the bulk import file and username, password.
$bulkImportCsv = "c:\bulkimport.csv"
$serverUserName = "USERID"
$serverPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$chassisUserName = "USERID"
$chassisPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$recoveryPassword = ConvertTo-SecureString "Password" -AsPlainText -Force


# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

# Bulk import servers
Write-Host "`nTry to manage servers via file:" $bulkImportCsv
$ret = Add-LXCAManagedDevice -BulkImportFile $bulkImportCsv -CurrentRackServerUserName $serverUserName -CurrentRackServerPassword $serverPassword -CurrentChassisUserName $chassisUserName -CurrentChassisPassword $chassisPassword -ChassisRecoveryPassword $recoveryPassword
Write-Host "`nManaged chassis:"
$ret.ChassisManageResult | Format-Table -Wrap
Write-Host "`nManaged rack server:"
$ret.RackServerManageResult | Format-Table -Wrap

# wait until the inventory state is not "Pending" after management
$bWait = $true
while ($bWait)
{
	Start-Sleep -Seconds 20
	Foreach($chassisRet in $ret.ChassisManageResult)
	{
        $allNonPending = $true
		if ($chassisRet.Success -eq $true)
		{
			$chassis = Get-LXCAChassis -ChassisUuid $chassisRet.Uuid
			if ($chassis.AccessState -eq "Pending")
			{
                $allNonPending = $allNonPending -and $false
                break
			}
            else
			{
                $allNonPending = $allNonPending -and $true
			}
            $allNonPending
            $bWait = -not $allNonPending
		}
	}
}

# Configure them via configuration pattern
# Configure compute node
Foreach($chassisRet in $ret.ChassisManageResult)
{
    # Check if the chassis is managed succesfully
    if ($chassisRet.Success -eq $true)
    {
        # Get the compute node list in this chassis
        $computeNodes = Get-LXCAComputeNode -ChassisUuid $chassisRet.Uuid | Select-Object -Property Uuid
        $nodeUuids = @()
        foreach ($node in $computeNodes)
        {
            # config pattern only accepts uuid in upper case
            $nodeUuids += $node.Uuid.ToUpper()
        }
		# Get pattern due to the pattern name
		$pattern = Get-LXCAConfigPattern | where { $_.Name -eq $configPattern.flex}
		if ($pattern -eq $null)
		{
			Write-Host ("`nCannot get pattern with name {0}" -f $configPattern.flex) -ForegroundColor Red
		}
		else
		{
			# Deploy pattern to the compute nodes
			Write-Host "`nDeploy pattern to compute nodes under chassis" $chassisRet.Uuid
			$ret = Install-LXCAConfigPattern -PatternId $pattern.Id -TargetComputeNodeId $nodeUuids -Restart Immediate
			$ret | Format-Table -Property Uuid,Success
		}
    }
}

# wait until the inventory state is not "Pending" after management
$bWait = $true
while ($bWait)
{
	Start-Sleep -Seconds 20
	Foreach($serverRet in $ret.RackServerManageResult)
	{
        $allNonPending = $true
		if ($serverRet.Success -eq $true)
		{
			$server = Get-LXCARackServer -Uuid $serverRet.Uuid
			if ($server.AccessState -eq "PENDING")
			{
                $allNonPending = $allNonPending -and $false
                break
			}
            else
			{
                $allNonPending = $allNonPending -and $true
			}
            $allNonPending
            $bWait = -not $allNonPending
		}
	}
}

# Configure rack server
$serverUuids = @()
Foreach($serverRet in $ret.RackServerManageResult)
{
    # Check if the server is managed succesfully
    if ($serverRet.Success -eq $true)
    {
        # config pattern only accepts uuid in upper case
        $serverUuids += $serverRet.Uuid.ToUpper()
    }
}
if ($serverUuids.Count -gt 0)
{
		# Get pattern due to the pattern name
		$pattern = Get-LXCAConfigPattern | where { $_.Name -eq $configPattern.rack}
		if ($pattern -eq $null)
		{
			Write-Host ("`nCannot get pattern with name {0}" -f $configPattern.rack) -ForegroundColor Red
		}
		else {
			# Deploy pattern to the rack servers
			Write-Host ("`nDeploy pattern to rack servers {0}" -f [string]::Join(",",$serverUuids))
			$ret = Install-LXCAConfigPattern -PatternId $pattern.Id -TargetRackServerId $serverUuids -Restart Immediate
			$ret | Format-Table -Property Uuid,Success
		}
}


# Disconnect LXCA
Disconnect-LXCA