# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2022 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

function SetInactiveEth()
{
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]$Interface
    )
    $ifaceUri = "/aicc/network/interfaces"
    $inactiveRequestBody = @{
        id = $Interface
        role = @("none")
    } | ConvertTo-Json -Depth 2 -Compress
    Invoke-LXCARestMethod -ResourceUrl "$ifaceUri/$Interface" -Method PUT -RequestBody $inactiveRequestBody
}

function SetActiveEth()
{
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]$Interface,
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String[]]$Roles
    )
    $ifaceUri = "/aicc/network/interfaces"
    $activeRequestBody = @{
        id = $Interface
        role = $Roles
        ip_addresses = @(
            @{
                assign_method = "dhcp"
                version = 6
            }
            @{
                assign_method = "dhcp"
                version = 4
            })
    } | ConvertTo-Json -Depth 2 -Compress
   Invoke-LXCARestMethod -ResourceUrl "$ifaceUri/$Interface" -Method PUT -RequestBody $activeRequestBody
}

function SetActiveEthStatic()
{
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]$Interface,
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String[]]$Roles,
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String[]]$IPv4
    )
    $ifaceUri = "/aicc/network/interfaces"
    $activeRequestBody = @{
        id = $Interface
        role = $Roles
        ip_addresses = @(
            @{
                assign_method = "dhcp"
                version = 6
            }
            @{
                assign_method = "static"
                version = 4
                ip = $IPv4
                prefix_length = 24
            })
    } | ConvertTo-Json -Depth 2 -Compress
   Invoke-LXCARestMethod -ResourceUrl "$ifaceUri/$Interface" -Method PUT -RequestBody $activeRequestBody
}

function ResetLXCA()
{
    $body = @{
        appliance = @{
            runlevel = 6
        }
    } | ConvertTo-Json -Depth 2 -Compress
    Invoke-LXCARestMethod -ResourceUrl "/aicc" -Method PUT -RequestBody $body
}

$managementRole = "management"
$osdeploymentRole = "osdeployment"

$LxcaIPs = @("192.168.1.184", "192.168.25.10")

# First connect to LXCA server
$lxcaPassword = ConvertTo-SecureString "userPassword" -AsPlainText –Force
$userName = "userName"
$Cred = New-Object System.Management.Automation.PSCredential($userName, $lxcaPassword)
Connect-LXCA -Host $LxcaIPs[1] -Credential $Cred -SkipCertificateCheck


<#
# disable eth1 interface
SetInactiveEth -Interface "eth1"

# set static IPv4 address for eth1 interface
SetActiveEthStatic -Interface "eth1" -Roles @($osdeploymentRole) -IPv4 "192.168.25.111"

#>
SetActiveEth -Interface "eth0" -Roles @($managementRole)
SetActiveEth -Interface "eth1" -Roles @($osdeploymentRole)

# restart LXCA appliance to load new settings
ResetLXCA

# disconnecting from the LXCA isn't needed but is here for consistency.
Disconnect-LXCA

