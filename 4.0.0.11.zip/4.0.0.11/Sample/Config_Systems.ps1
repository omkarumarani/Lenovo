# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
Config_Systems.ps1
- Example scripts to illustrate how to deploy config pattern to target systems.
#>


# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"

# The pattern id, you can get it by cmdlet Get-LXCAConfigPattern
$patternId = 4
$referenceSystemUuid = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
$targetSystems = "226B3EA4DF7A11D493E6951515157171","FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"



# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

if ($patternId -eq "")
{
    $profile = Get-LXCAConfigProfile | where {$_.ServerUuid -eq $referenceSystemUuid}
    if ($profile -ne $null)
    {
        $patternId = $profile[0].PatternId
    }
}

if ($patternId -eq "")
{
    Write-Error -Message "Pattern Id is empty (cannot retrieve pattern id from reference system)."
}
else
{
    Write-Host ("`nDeploy pattern {0} to target systems {1}." -f $patternId,([string]::Join(",",$targetSystems)))
    $ret = Install-LXCAConfigPattern -PatternId $patternId -TargetRackServerId $targetSystems -Restart Defer
    if ($ret -eq $null)
    {
        Write-Host "Install-LXCAConfigPattern is failed with unexcepted error!" -ForegroundColor Red
    }
    else
    {
        $ret | Format-Table -Property Uuid,Success
    }
}


# Disconnect from LXCA server
Disconnect-LXCA