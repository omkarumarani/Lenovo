# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
End_to_end.ps1
- Example scripts to illustrate how to end to end rollout the new system via PowerShell.
- Manage system, firmware update, configuration, os deployment.
#>


# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"

# Define reference system and target systems, here assume all system is rack server
# Reference system should have been managed in LXCA and has been assigned the update policy and config pattern.
$referenceSystem = @{
        uuid = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        systemType = "RackServer"
    }

$targetSystem = @{
        uuid = "89B8E140DF7C11D49AB09F8B8B8B8B8B" 
        systemType = "RackServer"
        username = "USERID"
        password = ConvertTo-SecureString "Password" -AsPlainText -Force
        recovery = ConvertTo-SecureString "Password" -AsPlainText -Force
    }
$deploySet = @{
        macAddress = "40:F2:E9:B8:1B:68"
        imageProfileId = "win2012|win2012-x86_64-install-Datacenter"
        targetDevice = "localdisk"		# localdisk / usbdisk / sandisk (SAN ID is required)
        IpAssignment = "dhcpv4"			# dhcpv4 / staticv4
    }


# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

# Manage target system in LXCA server
if ($targetSystem.systemType -eq "RackServer")
{
    $ret = Add-LXCAManagedDevice -RackServerUuid $targetSystem.uuid -UserName $targetSystem.username -Password $targetSystem.password
}
else
{
    $ret = Add-LXCAManagedDevice -ChassisUuid $targetSystem.uuid -UserName $targetSystem.username -Password $targetSystem.password -ChassisRecoveryPassword $targetSystem.recovery
}

# wait until the inventory state is not "Pending" after management
$bWait = $true
while ($bWait)
{
	Start-Sleep -Seconds 20
	if ($targetSystem.systemType -eq "RackServer")
	{
		$server = Get-LXCARackServer -Uuid $targetSystem.uuid
        if ($server.AccessState -eq "Pending")
		{
			continue
		}
	}
	else
	{
		$chassis = Get-LXCAChassis -ChassisUuid $targetSystem.uuid
        if ($chassis.AccessState -eq "Pending")
		{
			continue
		}
	}
	$bWait = $false
}

# Update firmware to the same level with reference system, assume the related update packages have been existed on LXCA repository.
# Get the update policy from reference system
$policy = Get-LXCAUpdateCompliancePolicy -SystemUuid $referenceSystem.uuid -SystemType $referenceSystem.systemType
# Assign the policy to target system
$compliance = Join-LXCAUpdateCompliancePolicy -Policy $policy -SystemUuid $targetSystem.uuid -SystemType $targetSystem.systemType
# Perform firmware update due to the compliance result
$ret = Install-LXCAUpdatePackage -Compliance $compliance -UpdateRule NotCompliantOnly -ActivationMode Delayed -OnErrorMode ContinueOnError -Simulation
if ($ret -eq $null)
{
    Write-Host "Install-LXCAUpdatePackage is failed with unexcepted error!" -ForegroundColor Red
}
else
{
    Write-Host "`nFirmware update result:"
    $ret | Format-Table -Property Uuid,Type,TotalTasks,TotalSuccess,TotalFailed
    $ret.Components | Format-Table -Property ComponentName,UpdateStatus,Message
}

# Wait 60 seconds
#Start-Sleep -Seconds 60

# Apply the same config pattern from reference system to target system
# Get the same config pattern which is used on reference system.
$patternId = ""
$profile = Get-LXCAConfigProfile | where {$_.ServerUuid -eq $referenceSystem.uuid}
if ($profile -ne $null)
{
    $patternId = $profile[0].PatternId
}
# Apply the config pattern to target system
if ($patternId -eq "")
{
    Write-Error -Message "Pattern Id is empty (cannot retrieve pattern id from reference system)."
}
else
{
    Write-Host ("`nDeploy pattern {0} to target systems {1}." -f $patternId,([string]::Join(",",$targetSystems)))
    $ret = Install-LXCAConfigPattern -PatternId $patternId -TargetRackServerId $targetSystems -Restart Defer
    if ($ret -eq $null)
    {
        Write-Host "Install-LXCAConfigPattern is failed with unexcepted error!" -ForegroundColor Red
    }
    else
    {
        $ret | Format-Table -Property Uuid,Success
    }
}

# Wait 60 seconds
#Start-Sleep -Seconds 60

# Deploy OS image to target system
# Set global deploy setting
$globalSet = Get-LXCADeployGlobalSetting
$globalSet.IpAssignment = $deploySet.IpAssignment
Set-LXCADeployGlobalSetting -DeployGlobalSetting $globalSet
# Create a deploy task
$deployTask = New-LXCADeployTask -MacAddress $deploySet.macAddress -ServerUuid $targetSystem.uuid -ImageProfileID $deploySet.imageProfileId -TargetDevice $deploySet.targetDevice -Mtu 1500 -PrefixLength 0
# Deploy OS image to target system
$ret = Install-LXCAOSImage -DeployTask $deployTask
if ($ret -eq $null)
{
    Write-Host "Install-LXCAOSImage is failed with unexcepted error!" -ForegroundColor Red
}
else
{
    $ret | Format-Table -Property ServerUuid,Percentage,Result,Message -Wrap
}

# Disconnect from LXCA
Disconnect-LXCA