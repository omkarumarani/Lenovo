# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
Firmware_Update.ps1
- Example scripts to illustrate how to update firmware.
#>


# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"

# Define reference system and target systems, here assume all system is rack server
$referenceSystemUuid = "226B3EA4DF7A11D493E6951515157171"
$targetSystems = "226B3EA4DF7A11D493E6951515157171"

# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

# Get the update policy from reference system
$policy = Get-LXCAUpdateCompliancePolicy -SystemUuid $referenceSystemUuid -SystemType RackServer | where {$_.SystemUuid -eq $referenceSystemUuid}

if ($policy -eq $null)
{
    Write-Host ("Cannot find policy from reference system {0}." -f $referenceSystemUuid) -ForegroundColor Red
}
else
{
    Write-Host ("`nGet policy {0}." -f $policy.Name)
    # Perform firmware update on each target system (now it is simulation mode in this sample)
    foreach ($uuid in $targetSystems)
    {
        Join-LXCAUpdateCompliancePolicy -Policy $policy -SystemUuid $uuid -SystemType RackServer
        $compliance = Get-LXCASystemCompliance -SystemUuid $uuid -SystemType RackServer
        $ret = Install-LXCAUpdatePackage -Compliance $compliance -UpdateRule NotCompliantOnly -ActivationMode Immediate -OnErrorMode ContinueOnError
        if ($ret -eq $null)
        {
            Write-Host ("Install-LXCAUpdatePackage is failed on {0} with unexcepted error!" -f $uuid) -ForegroundColor Red
        }
        else
        {
            Write-Host ("`nFirmware update result on {0}:" -f $uuid)
            $ret | Format-Table -Property Uuid,Type,TotalTasks,TotalSuccess,TotalFailed
            $ret.Components | Format-Table -Property ComponentName,UpdateStatus,Message -Wrap
        }
    }
}

#Disconnect from LXCA
Disconnect-LXCA