# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
Manage_Systems.ps1
- Example scripts to illustrate how to manage systems on LXCA server.
#>

# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"

$ChassisUserName = "USERID"
$ChassisPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$RecoveryPassword = ConvertTo-SecureString "Password" -AsPlainText -Force

$ServerUserName = "USERID"
$ServerPassword = ConvertTo-SecureString "Password" -AsPlainText -Force


# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

# Manage chassis via S/N, precondition is the target chassis have been discovered by LXCA server
$SNlist = "23ENY12","23ENY13","23EVN14","23EVN15"
Write-Host "`nTry to manage chassis with S/N:" $SNlist
$standaloneChassis = Get-LXCAChassis -Unmanaged | where { $_.SerialNumber -in $SNlist }
Write-Host "`nStandalone chassis discovered by LXCA server:"
$standaloneChassis | Sort-Object Name | Format-Table -Property Name,UUID,SerialNumber,IPAddresses -AutoSize
$Uuids = @()
foreach ($Chassis in $standaloneChassis){
  $Uuids += ,@($Chassis.Uuid)
  } 
$Uuids = [string[]]$Uuids
$ret = Add-LXCAManagedDevice -ChassisUuid $Uuids -UserName $ChassisUserName -Password $ChassisPassword -ChassisRecoveryPassword $RecoveryPassword
Write-Host "`nManage chassis result:"
$ret | Format-Table -AutoSize

# Manage servers via IP address or IP range
$IpRange = "10.240.195.40-10.240.195.50"
Write-Host "`nTry to manage servers in IP range" $IpRange
$ret = Add-LXCAManagedDevice -Ipv4Range $IpRange -UserName $ServerUserName -Password $ServerPassword
Write-Host "`nManaged chassis:"
$ret.ChassisManageResult | Format-Table -Wrap
Write-Host "`nManaged rack server:"
$ret.RackServerManageResult | Format-Table -Wrap

# Manage chassis/rack server via bulk import csv
# The bulk import csv template can be downloaded from web ui
<#
$csvPath = "C:\bulkimport.csv"
Write-Host "`nTry to manage servers via file:" $csvPath
$ret = Add-LXCAManagedDevice -BulkImportFile $csvPath -CurrentRackServerUserName $ServerUserName -CurrentRackServerPassword $ServerPassword
Write-Host "`nManaged chassis:"
$ret.ChassisManageResult | Format-Table -Wrap
Write-Host "`nManaged rack server:"
$ret.RackServerManageResult | Format-Table -Wrap
#>

<#
# Power off all managed rack servers
$allServers = Get-LXCARackServer
Write-Host "`nAll managed rack servers"
$allServers | Sort-Object Name | Format-Table -Property Name,MachineType,IPAddresses,AccessState,HealthState,PowerState -Wrap
# Power off each rack server
Foreach ($server in $assServers)
{
    Invoke-LXCASystemAction -RackServerUuid $server.Uuid -RackServerAction ShutdownOSandPowerOff
}
# Wait 10 mins to get the result again
Start-Sleep -Seconds (60*10)
$allServers = Get-LXCARackServer
Write-Host "`nAll managed rack servers after PowerOff:"
$allServers | Sort-Object Name | Format-Table -Property Name,MachineType,IPAddresses,AccessState,HealthState,PowerState -Wrap
#>

# Disconnect from LXCA server
Disconnect-LXCA