# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2017 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
Management_Server_Update.ps1
- Example scripts to illustrate how to import management pack and update it.
#>


# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Passw0rd" -AsPlainText -Force
$LxcaIP = "10.240.211.112"

# Define folder where the management packs are stored
$folder = 'D:\tmp\managementPacks'
# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

# import the management packs
Import-LXCAUpdatePackage -Folder $folder -ApplianceUpdate


#when import is successful, start to apply it

# Define apply REST
$rest="/managementServer/updates?action=apply"
# Define request boday which will be applied, it only allow to apply one pack at once in current release
$requestBody = '{"fixids":["lnvgy_sw_lxca_5-1.3.2_anyos_noarch"]}'

#use common REST cmdlet to do apply
Invoke-LXCARestMethod -ResourceUrl $rest -Method PUT -RequestBody $requestBody

#Disconnect from LXCA
Disconnect-LXCA