# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
Monitor_Events.ps1
- Example scripts to illustrate how to monitor the events on LXCA server.
#>

#
# Please run this script in PowerShell console and keep the windows opened.
#

# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.196.152"

# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

# Create a monitor which will monitor all incoming events with severity CRITIAL,FATAL and WARNING.
# It will re-connect to Lenovo XClarity Administrator when the network is not available or the management server is rebooted, and to continue monitoring events.
$monitor = Start-LXCAEventMonitor -Severity CRITICAL,FATAL,WARNING

Write-Host "`nStart to monitor event..."
Write-Host "`nPlease do not close the PowerShell windows"
Write-Host "If you want to stop the monitor, run below commands in the console:"
Write-Host '$monitor.StopMonitor()' -ForegroundColor Green


# Register this monitor, send a mail when there is new event incoming. 
# You also can record the events to local file or deal with them in other ways.
# Here the value of -EventName must be LXCAEvent which is defined in Start-LXCAEventMonitor
# View http://technet.microsoft.com/en-us/library/dd347672.aspx for help on cmdlet Register-ObjectEvent
$ret = Register-ObjectEvent -InputObject $monitor -EventName LXCAEvent -Action {
       
    #Create a Email message
    $msg = new-object Net.Mail.MailMessage

    #Create SMTP server object
    $smtp = new-object Net.Mail.SmtpClient("smtp.gmail.com")
    $smtp.Credentials = New-Object System.Net.NetworkCredential("yourid@gmail.com", "yourpassword")
    #Port for TLS (587) or SSL (465)
    $smtp.Port = 587
    $smtp.EnableSsl = $true
    #Ignore SSL trust validation
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

    #Email content
    $msg.From = "yourid@gmail.com"
    $msg.To.Add("name@company.com")
    
    #Get all incoming events from $EventArgs.Events.
    #Here the event has the same structure as the event returned by cmdlet Get-LXCAEvent.
    foreach ($event in $EventArgs.Events)
    {
        $msg.subject = "Event -" + $event.EventID + ": " + $event.Message
        $msg.body = Out-String -InputObject $event

        #Send email
        $smtp.Send($msg)

        #Record event to local file
        Out-File -InputObject $event -FilePath c:\monitor.txt -Append
    }
}
