# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
OS_Deployment.ps1
- Example scripts to illustrate how to deploy os image to target systems.
#>

# Function to wait for jobs to be deployed to LXCA
function WaitForDeployJobsToStart ([System.Management.Automation.Job[]]$allJobs)
{
    $allJobsStarted = 0
    $sleepTime = 5
    $jobsCount = $allJobs.Count

    Write-Host "Trying to start $jobsCount jobs."

    while($allJobsStarted -eq 0)
    {
        $allJobsStarted = 1
        foreach ($i in $allJobs)
        {
            if ($i.State -eq "NotStarted" )
            {
                $allJobsStarted = 0
                break
            }
        }
        if ($allJobsStarted -eq 0)
        {
            Write-Host "wait for $sleepTime seconds"
            Start-Sleep -Seconds $sleepTime
        }
    }
    # show final status: give some time to update jobs information from LXCA: maybe you have failed tasks.
    Write-Host "Sleeping for 10 seconds..."
    $counter = 10
    while ($counter -gt 0)
    {
        Write-Host -NoNewline "."
        Start-Sleep -Seconds 1
        $counter--
    }
    Write-Host
    Write-Host "Final result:"
    foreach ($i in $allJobs)
    {
        Write-Host "Job $($i.Id) with state $($i.State)"
    }
}

# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"

$targetSystem = @{
        uuid = "89B8E140DF7C11D49AB09F8B8B8B8B8B"
        systemType = "RackServer"
    }
$deploySet = @{
        macAddress = "40:F2:E9:B8:1B:68"
        imageProfileId = "win2012|win2012-x86_64-install-Datacenter"
        targetDevice = "localdisk"		# localdisk / usbdisk / sandisk (SAN ID is required)
        IpAssignment = "dhcpv4"			# dhcpv4 / staticv4 / staticv6
    }

# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck


# Deploy OS image to target system
# Set global deploy setting
$globalSet = Get-LXCADeployGlobalSetting
$globalSet.IpAssignment = $deploySet.IpAssignment
Set-LXCADeployGlobalSetting -DeployGlobalSetting $globalSet

# Create a deploy task
$deployTask = New-LXCADeployTask -MacAddress $deploySet.macAddress -ServerUuid $targetSystem.uuid `
                                 -ImageProfileID $deploySet.imageProfileId -TargetDevice $deploySet.targetDevice -Mtu 1500 -PrefixLength 0

# Deploy OS image to target system
$ret = Install-LXCAOSImage -DeployTask $deployTask
if ($ret -eq $null)
{
    Write-Host "Install-LXCAOSImage is failed with unexcepted error!" -ForegroundColor Red
}
else
{
    Write-Host "Deploy kicked off to $($targetSystem.uuid) => job id $($ret.Id) with state $($ret.State)"
}

# Wait for job to be deployed and Started on LXCA. There are two possible outputs:
# Job started successfuly on LXCA:
#       Job 16 with state Running
# Job Failed to start on LXCA:
#       Job 8 with state Failed

$jobs = @($ret)
WaitForDeployJobsToStart($jobs)

# Disconnect from LXCA server
Disconnect-LXCA
