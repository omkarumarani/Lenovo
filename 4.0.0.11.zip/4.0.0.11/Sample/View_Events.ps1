# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
View_Events.ps1
- Example scripts to illustrate how to view the events on LXCA server.
#>

# Define the variable value
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"

# First connect to LXCA server
$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck


# Get all events in previous 2 hours
$allEvents = Get-LXCAEvent -PreviousHours 2
Write-Host "`nAll events in previous 2 hours:"
$allEvents | Sort-Object -Property SequenceNumber | Format-Table -Property SequenceNumber,EventID,Severity,Message,TimeStamp,SourceID,EventClass -Wrap

# Get events from target system with specified severity 
$systemUuid = "BB6EEE4EDF8811D49D17C70202020202"

$severity = "MAJOR","CRITICAL","FATAL"
Write-Host ("`nEvents on system {0} with severity {1}:" -f $systemUuid,([string]::Join(",",$severity)))
$events = Get-LXCAEvent -SourceID $systemUuid -Severity $severity
$events | Sort-Object -Property SequenceNumber | Format-Table -Property SequenceNumber,EventID,Severity,Message,TimeStamp,SourceID,EventClass -Wrap

# Get all active status with specified severity
<# Now active status returns 500 error
$severity = "CRITICAL","FATAL"
Write-Host ("`nSystems with active status in severity {0}:" -f ([string]::Join(",",$severity))
$status = Get-LXCAActiveStatus -Severity $severity
$status | Sort-Object -Property SourceID | Format-Table -Wrap
#>


#Disconnect from LXCA
Disconnect-LXCA