# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2015 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

<#
View_Systems.ps1
- Example scripts to illustrate how to view the managed systems on lxca server.
#>

# First connect to LXCA server
$LxcaUserName = "USERID"
$LxcaPassword = ConvertTo-SecureString "Password" -AsPlainText -Force
$LxcaIP = "10.240.197.26"


$Cred = New-Object System.Management.Automation.PSCredential($LxcaUserName, $LxcaPassword)
Connect-LXCA $LxcaIP -Credential $Cred -SkipCertificateCheck

# View the LXCA version
Get-LXCAInformation

# List all managed chassis
$allChassis = Get-LXCAChassis
Write-Host ""
Write-Host ("There are {0} chassis managed by this LXCA server." -f $allChassis.Count)
$allChassis | Sort-Object Name | Format-Table -Property Name,MachineType,IPAddresses,AccessState,HealthState -Wrap

# List all compute nodes on each chassis
ForEach ($chassis in $allChassis)
{
    $nodes = Get-LXCAComputeNode -ChassisUuid $chassis.Uuid
    Write-Host ""
    Write-Host $chassis.Name ": there are" $nodes.Count "compute nodes in this chassis."
    $nodes | Sort-Object Name | Format-Table -Property Name,MachineType,IPAddresses,HealthState,PowerState -Wrap
}

# List all managed rack servers (and record result to c:\lxca.txt)
$allServers = Get-LXCARackServer
Write-Host ("`nThere are {0} rack server managed by this LXCA server." -f $allServers.Count )
$allServers | Sort-Object Name | Format-Table -Wrap
$allServers | Sort-Object Name | Format-Table -Property Name,MachineType,IPAddresses,AccessState,HealthState,PowerState -Wrap >> c:\lxca.txt


# Disconnect from LXCA server
Disconnect-LXCA