# ------------------------------------------------------------------
# Lenovo Copyright
#
# (C) Copyright Lenovo 2022 - present.
#
# LIMITED AND RESTRICTED RIGHTS NOTICE:
# If data or software is delivered pursuant a General Services
# Administration (GSA) contract, use, reproduction, or disclosure
# is subject to restrictions set forth in Contract No. GS-35F-05925.
# ------------------------------------------------------------------

$scaleIP = "192.168.1.184"
$edgePath = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
$userMode = "multiUser"

$cred = Get-Credential

Connect-LXCA -Host $scaleIP -Credential $cred -SkipCertificateCheck

$servers = Get-LXCAServer

$xccServers = @()

foreach ($item in $servers)
{
    if ($item.IsManaged -eq $true -and `
        $item.IsRemotePresenceEnabled -eq $true -and `
        $item.MgmtProcType -like "XCC" -and `
        $item.AccessState -like "Online")
    {
        $xccServers += $item
    }
}

# start remote control for XCC.
$urlList = $null
foreach ($xcc in $xccServers)
{
    # get xcc rc link
    $result = Invoke-LXCARestMethod -Method GET -ResourceUrl "/remoteaccess/remoteControl?uuid=$($xcc.Uuid)&userMode=multiUser"
    $url = $result.Body.Split(":{}")
    $rcUrl = ($url[2] + ":" + $url[3]).Trim('\"').Replace('\/', '/')
    $urlList = $urlList + $rcUrl + " "
}

Start-Process $edgePath -ArgumentList "--new-window $($urlList)"

Disconnect-LXCA
